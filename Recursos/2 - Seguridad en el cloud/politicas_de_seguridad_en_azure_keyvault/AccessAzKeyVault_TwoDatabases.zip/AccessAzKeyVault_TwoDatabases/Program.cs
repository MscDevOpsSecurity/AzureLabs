﻿using System;
using System.Collections.Generic;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Microsoft.Data.SqlClient;

namespace AccessAzKeyVault_TwoDatabases
{
    /// <summary>
    /// Application to demonstrate that we can access the same Azure KeyVault from 2 different VMs using Managed Identities.
    /// </summary>
    internal class Program
    {
        private static SecretClient client = null;        
        private static string kv = "azkeyvault-testing2022";
        private static string KEYVAULT_BASE_URI = $"https://{kv}.vault.azure.net/";
        private static List<dbContent> databases = new() 
        { 
            new dbContent("Database 1"), 
            new dbContent("Database 2") 
        };

        static void Main(string[] args)
        {
            string option;
                                               
            do
            {
                PrintMenu();

                Console.Write("> Option: ");
                option = Console.ReadLine();

                switch (option)
                {
                    case "1":
                        RetrieveInfo_ManagedIdentity(0);
                        ReadFromDatabase(0);
                        break;
                    case "2":
                        RetrieveInfo_ManagedIdentity(1);
                        ReadFromDatabase(1);
                        break;
                }
                
            } while (option != "0");
        }

        private static void PrintMenu()
        {
            Console.Clear();
            Console.WriteLine($"MACHINE: {Environment.MachineName}");
            Console.WriteLine("If the permissions are granted, values from database selected will be printed out...");
            Console.WriteLine("---------------------------------------------------------------------------");
            Console.WriteLine("Select and option to retrieve secrets");
            Console.WriteLine("  (0) - Exit");
            Console.WriteLine("  (1) - Retrieve data from Azure KeyVault (Managed Identity) => Database 1");
            Console.WriteLine("  (2) - Retrieve data from Azure KeyVault (Managed Identity) => Database 2");
        }

        /// <summary>
        /// Using the token from the default session (az login) or from ManagedIdentity, RBAC
        /// </summary>
        private static void RetrieveInfo_ManagedIdentity(int databaseNumber)
        {
            try
            {
                Console.Clear();
                client = new SecretClient(new Uri(KEYVAULT_BASE_URI), new DefaultAzureCredential());

                Console.WriteLine($"*** READING FROM: {databases[databaseNumber].DBName} *** ");

                var secret = client.GetSecret($"usernamedb{databaseNumber}");                    
                databases[databaseNumber].UserID = secret.Value.Value;
                Console.WriteLine($"[OK] Secret read: <Username={databases[databaseNumber].UserID}>");

                secret = client.GetSecret($"passworddb{databaseNumber}");
                databases[databaseNumber].Password = secret.Value.Value;
                Console.WriteLine($"[OK] Secret read: <Password={databases[databaseNumber].Password}>");

                secret = client.GetSecret($"datasourcedb{databaseNumber}");
                databases[databaseNumber].DataSource = secret.Value.Value;
                Console.WriteLine($"[OK] Secret read: <DataSource={databases[databaseNumber].DataSource}>");

                secret = client.GetSecret($"initialcatalogdb{databaseNumber}");
                databases[databaseNumber].InitialCatalog = secret.Value.Value;
                Console.WriteLine($"[OK] Secret read: <InitialCatalog={databases[databaseNumber].InitialCatalog}>");

                //Console.Write("     Press Enter to go back to menu...");
                //Console.Read();
            }
            catch (Exception keyVaultException)
            {
                Console.WriteLine($"[ERROR] {keyVaultException.Message}");
                Console.Read();
            }
        }

        /// <summary>
        /// Reads dummy data from database.
        /// </summary>
        private static void ReadFromDatabase(int databaseNumber)
        {
            try
            {
                var builder = new SqlConnectionStringBuilder();
                builder.DataSource = databases[databaseNumber].DataSource; // <instancedb>.database.windows.net
                builder.UserID = databases[databaseNumber].UserID;
                builder.Password = databases[databaseNumber].Password;
                builder.InitialCatalog = databases[databaseNumber].InitialCatalog;

                using (var connection = new SqlConnection(builder.ConnectionString))
                {
                    Console.WriteLine("\nQuery data example:");
                    Console.WriteLine("=========================================\n");

                    var sql = "SELECT TOP (5) FirstName, LastName FROM SalesLT.Customer";

                    using (var command = new SqlCommand(sql, connection))
                    {
                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Console.WriteLine("{0} {1}", reader.GetString(0), reader.GetString(1));
                            }
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                Console.WriteLine($"[ERROR] {sqlException.Message}");
            }
            Console.Write("     Press Enter to go back to menu...");
            Console.ReadLine();
        }
    }
}