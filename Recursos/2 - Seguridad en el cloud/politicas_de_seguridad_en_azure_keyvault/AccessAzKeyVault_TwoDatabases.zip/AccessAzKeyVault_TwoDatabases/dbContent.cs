﻿namespace AccessAzKeyVault_TwoDatabases
{
    public class dbContent
    {
        public string DBName { get; set; }
        public string DataSource { get; set; }
        public string UserID { get; set; }
        public string Password { get; set; }
        public string InitialCatalog { get; set; }

        public dbContent(string DBName)
        {
            this.DBName = DBName;
        }
    }
}
